package br.padroes.singleton;

public class Cliente {

	public static void main(String[] args) {
	    Fabrica fabrica = new Fabrica();
	    System.out.println(fabrica.criarCarroFiat());
	    System.out.println(fabrica.criarCarroFord());
	    System.out.println(fabrica.criarCarroVolks());
	 
	    System.out.println(fabrica.gerarRelatorio());
	}
}
