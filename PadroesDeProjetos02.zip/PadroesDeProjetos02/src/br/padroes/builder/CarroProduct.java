package br.padroes.builder;

public class CarroProduct {
  public double preco;
  public String dscMotor;
  public int anoDeFabricacao;
  public String modelo;
  public String montadora;
}
